<?php 
	$html_id = pxl_get_element_id($settings); 
	if($settings['style'] == 'style-1') {
		$svg_color1 = '#00d8ff';
		$svg_color2 = '#00ff12';
		$svg_color3 = '#121c27';
		$svg_color4 = '#4b535d';
	} else {
		$svg_color1 = '#0024ff';
		$svg_color2 = '#008f00';
		$svg_color3 = '#0042ff';
		$svg_color4 = '#4b535d';
	}
?>
<div class="pxl-banner pxl-banner1 <?php echo esc_attr($settings['style']); ?>">
	<div class="pxl-banner-inner">
		<?php if(!empty($settings['banner_image']['id'])) :
			$img = pxl_get_image_by_size( array(
				'attach_id'  => $settings['banner_image']['id'],
				'thumb_size' => 'full',
			));
			$thumbnail = $img['thumbnail']; ?>
			<div class="pxl-item--image">
				<?php echo pxl_print_html($thumbnail); ?>
			</div>
		<?php endif; ?>
		<svg class="pxl-svg-ani-01" xmlns="http://www.w3.org/2000/svg" width="445" height="490" viewBox="0 0 445 490">
			<defs>
				<linearGradient id="pxl-svg-ani-01-<?php echo esc_attr($html_id); ?>" x1="0%" y1="0%" x2="100%" y2="0%">
					<stop offset="0%" style="stop-color:<?php echo esc_attr($svg_color1); ?>;stop-opacity:1" />
					<stop offset="100%" style="stop-color:<?php echo esc_attr($svg_color2); ?>;stop-opacity:1" />
				</linearGradient>
			</defs>
			<path fill="url(#pxl-svg-ani-01-<?php echo esc_attr($html_id); ?>)" d="M425.838,151.942c51.155,124.875-6.183,267.131-132.28,319.286C229.435,497.7,170.2,492.984,139.454,459.1c-34-32.682-39.5-94.528-71.363-154.653C39.085,243.273-1.3,191.908,1.543,141.886,1.144,93.055,43.971,45.567,106.552,19.662c125.8-52.044,267.285,7.717,319.286,132.28"/>
		</svg>
		<svg class="pxl-svg-ani-02" xmlns="http://www.w3.org/2000/svg" width="490" height="442" viewBox="0 0 490 442">
			<defs>
				<linearGradient id="pxl-svg-ani-02-<?php echo esc_attr($html_id); ?>" x1="0%" y1="0%" x2="100%" y2="0%">
					<stop offset="0%" style="stop-color:<?php echo esc_attr($svg_color3); ?>;stop-opacity:1" />
					<stop offset="100%" style="stop-color:<?php echo esc_attr($svg_color4); ?>;stop-opacity:1" />
				</linearGradient>
			</defs>
			<path fill="url(#pxl-svg-ani-02-<?php echo esc_attr($html_id); ?>)" d="M161.212,16.55C288.03-29.579,427.883,33.392,474.962,161.471,498.854,226.6,491.776,285.6,456.7,314.967c-34.013,32.667-96.029,35.693-157.379,65.133-62.286,26.54-115.222,64.841-165.091,60-48.808-1.55-94.548-46.238-117.935-109.8C-30.69,202.526,34.672,63.536,161.212,16.55"/>
		</svg>
	</div>
</div>