<div class="pxl-banner pxl-banner2">
	<div class="pxl-banner-inner">
		<?php if(!empty($settings['banner_image']['id'])) :
			$img = pxl_get_image_by_size( array(
				'attach_id'  => $settings['banner_image']['id'],
				'thumb_size' => 'full',
			));
			$thumbnail = $img['thumbnail']; ?>
			<div class="pxl-item--image wow pxl-banner-effect1" data-wow-delay="200ms">
				<?php echo pxl_print_html($thumbnail); ?>
			</div>
		<?php endif; ?>
	</div>
</div>