{
	"icons": [
		"speech-bubble",
		"tag",
		"user",
		"right-arrow"
	]
}