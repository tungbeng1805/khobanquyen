<?php

$uri = get_template_directory_uri() . '/inc/admin/demo-data/demo-imgs/';
// Demos
$demos = array(
	// Elementor Demos
	'maiko' => array(
		'title'       => 'Maiko',	
		'description' => '',
		'screenshot'  => $uri . 'screenshot.webp',
		'preview'     => 'https://demo.bravisthemes.com/maiko/landing',
	),
);