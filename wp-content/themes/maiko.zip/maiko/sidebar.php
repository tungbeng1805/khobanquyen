<?php
/**
 * @package Bravis-Themes
 */

dynamic_sidebar( maiko()->get_sidebar() );