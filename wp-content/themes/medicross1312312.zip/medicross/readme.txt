Contributors: Medicross
Tags: custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready
