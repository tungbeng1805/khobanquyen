<?php
/**
 * @package Case-Themes
 */

dynamic_sidebar( medicross()->get_sidebar() );