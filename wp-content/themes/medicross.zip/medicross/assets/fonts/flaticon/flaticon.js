{
	"icons": [
		"speech-bubble",
		"tag",
		"user",
		"right-arrow",
		"next",
		"right-arrow-1"
	]
}
