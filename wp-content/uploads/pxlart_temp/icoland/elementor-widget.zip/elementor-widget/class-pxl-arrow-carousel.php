<?php

class PxlArrowCarousel_Widget extends Pxltheme_Core_Widget_Base{
    protected $name = 'pxl_arrow_carousel';
    protected $title = 'TN Nav Carousel';
    protected $icon = 'eicon-animation';
    protected $categories = array( 'pxltheme-core' );
    protected $params = '{"sections":[{"name":"content_alignment_section","label":"Content Alignment","tab":"content","controls":[{"name":"title","label":"Title","type":"text","label_block":true},{"name":"style","label":"Style","type":"select","options":{"style1":"Style 1"},"default":"style1"}]}]}';
    protected $styles = array(  );
    protected $scripts = array(  );
}